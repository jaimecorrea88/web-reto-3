//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://150.136.154.171:8080/api/Gama/all"

//referencia a secciones de la pagina mediante su id
let tableBody = document.getElementById("tableBody")
let seccionListar = document.getElementById("listar")
let seccionNuevo = document.getElementById("nuevo")
let botonNuevoGama =  document.getElementById("botonNuevoGama")
let botonApliGamaNuevoGama =  document.getElementById("botonApliGamaNuevoGama")

//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//registrar oyentes de eventos
botonNuevoGama.addEventListener("click",nuevaGama)
botonApliGamaNuevoGama.addEventListener("click",aplicarNuevoGama)
bottonCancelarNuevo.addEventListener("click",inicial)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function nuevaGama(){
    seccionListar.style.display='none'
    seccionNuevo.style.display='block'
    document.getElementById('nameGama').value=""
    document.getElementById('descriptionGama').value=""
    document.getElementById('nameGama').focus()
}

function inicial(){
    seccionNuevo.style.display="none"
    listar()
}

function aplicarNuevoGama (){
    url = "http://150.136.154.171:8080/api/Gama/save"

    //leer datos del formulario
    let nameGama = document.getElementById('nameGama').value
    let descriptionGama = document.getElementById('descriptionGama').value

    //generar peticion tipo post con la libreria axios
    axios.post(url,{
        name: nameGama,
        description: descriptionGama
    })
    .then(function (response){
        console.log(response.data)
        inicial()
    })
    .catch(function (error){
        console.log(error)
    })
}

function listar(){
    url="http://150.136.154.171:8080/api/Gama/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idGama + ' </td>' + 
                            '<td>' + items[i].name +'</td>' +
                            '<td>' + items[i].description.substring(0, 20) +'...</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary">Editar</button>' +
                            '    <button class="btn btn-outline-primary">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}
