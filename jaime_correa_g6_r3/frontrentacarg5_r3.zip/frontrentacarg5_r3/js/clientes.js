//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="http://150.136.154.171:8080/api/Client/all"

//Acceder a un elemento html que se identifica por un id
let seccionNuevo = document.getElementById("nuevo")
let seccionListar = document.getElementById("listar")
let tableBody = document.getElementById("tableBody")
let botonAplicarClienteNuevo =  document.getElementById("botonAplicarClienteNuevo")
let bottonCancelarNuevo =  document.getElementById("bottonCancelarNuevo")

//registro de eventos
botonNuevoCliente.addEventListener("click",nuevaCliente)
botonAplicarClienteNuevo.addEventListener("click",aplicarNuevoCliente)
bottonCancelarNuevo.addEventListener("click",inicial)

//almacena html de los registros a presentar en el listado de Clientes <tr><td>....</td></td></tr>
let resultados = ""

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

function inicial(){
    seccionNuevo.style.display="none"
    listar()
}

function nuevaCliente(){
    seccionNuevo.style.display="block"    
    seccionListar.style.display="none"
    document.getElementById("nameCliente").focus()
}

function aplicarNuevoCliente(){
    url="http://150.136.154.171:8080/api/Client/save"
    //leer informacion del Cliente editado o modificado
    let nameCliente = document.getElementById('nameCliente').value
    let emailCliente = document.getElementById('emailCliente').value
    let passwordCliente = document.getElementById('passwordCliente').value
    let edadCliente = document.getElementById('edadCliente').value
  
    axios.post(url, {
      name: nameCliente,
      email:emailCliente,
      password: passwordCliente,
      age: edadCliente
  })
    .then(function (response) {
      console.log(response.data);
      //actualizar tabla de datos
      inicial()      
    })
    .catch(function (error) {
      // manejar error
      console.log(error);
    })
  }

function listar(){
    url="http://150.136.154.171:8080/api/Client/all"
    resultados=""
    axios.get(url)
    .then(function (response){
        let items = response.data

        for(let i in items){
            resultados +=  '<tr>' + 
                            '<td>' + items[i].idClient + ' </td>' + 
                            '<td>' + items[i].name +'</td>' +
                            '<td>' + items[i].email +'</td>' +
                            '<td>' + items[i].age +'</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary">Editar</button>' +
                            '    <button class="btn btn-outline-primary">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}
