package com.atenea.retacarg5_r3.repository;

import com.atenea.retacarg5_r3.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message,Long> {
}
